import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import { X, Send, AlertCircle, MapPin, Navigation, Check, ChevronDown, ChevronUp } from 'lucide-react';

const rawApiUrl = import.meta.env.VITE_API_URL || 'https://crisis-misinformation-detector.onrender.com/api';
const API_BASE_URL = rawApiUrl.endsWith('/api') ? rawApiUrl : `${rawApiUrl.replace(/\/$/, '')}/api`;

const ReportForm = ({ onClose, user, location, onDetectLocation, onSuccess }) => {
  const { t } = useTranslation();
  const [type, setType] = useState('accident');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  // Mobile mode: allow collapsing form to see full map and tap anywhere
  const [isMinimizedForMap, setIsMinimizedForMap] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!location) {
      setError('Please tap on the map or click "Use My Location" to set the incident location');
      return;
    }
    if (!user) {
      setError('User session not initialized yet');
      return;
    }

    setLoading(true);
    setError('');
    try {
      const reportData = {
        userId: user._id,
        type,
        description,
        longitude: location.lng,
        latitude: location.lat,
      };

      if (navigator.onLine) {
        const res = await axios.post(`${API_BASE_URL}/reports`, reportData);
        onSuccess && onSuccess(res.data);
        onClose();
      } else {
        const offlineReports =
          JSON.parse(localStorage.getItem('offlineReports')) || [];

        offlineReports.push(reportData);
        localStorage.setItem(
          'offlineReports',
          JSON.stringify(offlineReports)
        );

        alert('No internet. Report saved locally and will sync automatically.');
        onSuccess && onSuccess(reportData);
        onClose();
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit report. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const crisisTypes = ['flood', 'fire', 'accident', 'earthquake', 'storm', 'medical'];

  // Minimized Banner Mode: gives user full-screen access to map to pinpoint location
  if (isMinimizedForMap) {
    return (
      <div className="slide-panel minimized-map-mode">
        <div className="sheet-handle-pill" onClick={() => setIsMinimizedForMap(false)} />
        <div className="map-picker-banner">
          <div className="map-picker-info">
            <div className="picker-icon-badge">
              <MapPin size={20} className="pulse-icon" />
            </div>
            <div className="picker-text">
              <strong>Tap anywhere on map to drop pin</strong>
              <span>
                {location
                  ? `Location set: ${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
                  : 'Touch map to pinpoint crisis location'}
              </span>
            </div>
          </div>

          <div className="map-picker-buttons">
            <button
              type="button"
              className="btn btn-primary btn-picker-done"
              onClick={() => setIsMinimizedForMap(false)}
            >
              <Check size={16} />
              <span>{location ? 'Confirm Pin' : 'Continue Form'}</span>
            </button>
            <button
              type="button"
              className="close-btn picker-close-btn"
              onClick={onClose}
              title="Cancel Report"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="slide-panel">
      {/* Mobile top handle */}
      <div className="sheet-handle-pill" onClick={() => setIsMinimizedForMap(true)} />

      <div className="slide-panel-header">
        <div>
          <h2>{t('reportEmergency')}</h2>
          <p>Tap map to pinpoint or fill details below</p>
        </div>
        <div className="header-action-group">
          {/* Mobile toggle to collapse form to full map */}
          <button
            type="button"
            className="btn btn-ghost btn-map-toggle-mobile"
            onClick={() => setIsMinimizedForMap(true)}
            title="View full map to pinpoint location"
          >
            <MapPin size={16} />
            <span>Pinpoint</span>
          </button>
          <button
            type="button"
            className="close-btn"
            onClick={onClose}
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="slide-panel-body">
        {error && (
          <div className="error-banner">
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="form-label">{t('crisisType')}</label>
          <div className="type-grid">
            {crisisTypes.map((tItem) => (
              <button
                key={tItem}
                type="button"
                onClick={() => setType(tItem)}
                className={`type-option ${type === tItem ? 'selected' : ''}`}
              >
                {tItem}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="form-label">{t('description')}</label>
          <textarea
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what is happening at the scene..."
            className="form-textarea"
          />
        </div>

        {/* Location selector box */}
        <div className="geo-tag-box">
          <div className="geo-tag-header">
            <div className="geo-tag-icon">
              <MapPin size={18} />
            </div>
            <div className="geo-tag-info">
              <p className="geo-tag-label">Crisis Location</p>
              <p className="geo-tag-value">
                {location
                  ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
                  : 'Tap map or click buttons below'}
              </p>
            </div>
          </div>

          {/* Action buttons to choose location */}
          <div className="geo-tag-actions">
            <button
              type="button"
              onClick={() => setIsMinimizedForMap(true)}
              className="btn btn-secondary btn-pick-on-map"
              title="Collapse form and tap map to place pin"
            >
              <MapPin size={14} />
              <span>Pinpoint on Map</span>
            </button>
            <button
              type="button"
              onClick={onDetectLocation}
              className="btn btn-ghost btn-use-my-loc"
              title="Use current GPS location"
            >
              <Navigation size={14} />
              <span>{t('detectLocation')}</span>
            </button>
          </div>

          <p className="geo-tag-tip">
            * Tip: Tap anywhere on the map above to drop the exact crisis pin.
          </p>
        </div>

        <button
          disabled={loading}
          type="submit"
          className="btn btn-primary btn-submit-report"
        >
          {loading ? t('submitting') : t('submitReport')}
        </button>
      </form>
    </div>
  );
};

export default ReportForm;
